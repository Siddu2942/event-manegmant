# Contributing to event-management
 ## Table of Contents
 #
 #1. [Introduction](#introduction)
 #2. [Getting Started](#getting-started)

 # Highlights
 
 - Point Three: 
   * Etl libs : 
	1) Python ETL Tool: Apache Airflow.
	2) Python ETL Tool: Luigi.
	3) Python ETL Tool: Pandas.
	4) Python ETL Tool: Bonobo.
	5) Python ETL Tool: petl.
	6) Python ETL Tool: PySpark.
	7) Python ETL Tool: Odo.
	8) Python ETL Tool: mETL. 


 # Echos
 
 - Point One 
 - Point Two
 - Point Three
 
 # How and When 
 


 # TO-DOs
 


 # Merge to STAG branch
 # Email Approved PR link to Project Manager
 # Happy Coding :-)
 - Point One 
 - Point Two
 - Point Two

